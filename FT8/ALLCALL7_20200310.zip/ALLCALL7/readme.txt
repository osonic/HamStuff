ALLCALL7.TXT file being used starting from v2.1.0-rc148 to filter false decodes.

Unpack and copy this file:

Windows OS: into [installation folder]\bin\data\